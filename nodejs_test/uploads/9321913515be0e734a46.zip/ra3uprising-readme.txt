﻿       
                                                                                
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

                              CHEATHAPPENS.com Presents:

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
                                                                                

Red Alert 3 Uprising Trainer
=============================

PUBLIC RELEASE DATE: JUNE 2, 2009


This is for the original retail version!

GET UPDATES FOR THIS TRAINER AT WWW.CHEATHAPPENS.COM



Using this Trainer
------------------
Launch the trainer first, then launch the Game and then Press F1 at the Main Menu.
Listen for "Activated".

Press desired option key


Options
-------

Numpad 1: Money
Numpad 2: Energy
Numpad 3: Top Secret Protocol Points
Numpad 4: Instant Build
Numpad 5: Instant Sidebar Powers
Numpad 6: Bombs / Ammunition
F1: Heal Unit / Building
F2: Drain Unit / Building
F3: Mega Unit / Building
F4: Normal Unit / Building
Numpad +: Plasma Force Armor
Numpad -: Nuclear Death Pulse
Numpad 0: Reveal Map


Notes
-------

Numpad 1: Money - unending money.

Numpad 2: Energy - set energy consumption to zero.

Numpad 3: Top Secret Protocol Points - you will have unending protocol points.

Numpad 4: Instant Build - units and buildings finish instantly.

Numpad 5: Instant Sidebar Powers - sidebar powers (Protocols) reset instantly.
	This may not work for all sidepowers and your MEGA weapons may have to
	power up at the start before this works for them.  We tried very hard
	to prevent the enemy from using this option.

Numpad 6: Bombs / Ammunition - mouse over unit with bombs/ammunition and press
	this key to give it 999 bombs/ammunition.

F1: Heal Unit / Building - mouse over unit/building and activate this option
	to heal it instantly.

F2: Drain Unit / Building - mouse over unit/building and activate this option
	to drain it's health instantly.

F3: Mega Unit / Building - mouse over unit/building and activate this option
	to create a very strong unit that takes damage very slowly.

F4: Normal Unit / Building - mouse over unit/building and activate this option
	to turn mega units back to normal units.

Numpad +: Plasma Force Armor - activate this and your forces create an invisible
	plasma shield which makes them invincible.  Some can still be killed 
	by getting run over, etc.

Numpad -: Nuclear Death Pulse - activate this and your forces will set off a
	Nuclear EMP pulse which will cripple all forces throughout many
	areas of the map.  Use it over and over again as new units are built
	to cripple them immediately.  This is pure carnage!  Careful as this
	will not affect YOUR troops but it will affect FRIENDLY troops!

Numpad 0: Reveal Map - activate this before the round starts to see the entire
	map OR you can activate while in a round and then build something to
	reveal the map.



This trainer will allow you to customize the keys if you desire!  Use our
Trainer Customizer to accomplish this! Download it from our trainer 
troubleshooting page (link below).


Having trouble getting the trainer to work? Visit our forums at www.cheathappens.com
and check out our TRAINER TROUBLESHOOTING GUIDE for helpful tips:

http://www.cheathappens.com/trainer_troubleshooting.asp



AUTHENTICITY NOTICE (Does not apply to PROMO or FREE trainers):
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 
In an effort to maintain the integrity of the files downloaded from our site and to prevent
illegal file sharing, this trainer will perform an authenticity check while in use. This check
requires an Internet connection and the trainer will not run if a connection is absent or if the
trainer is blocked by a security application. NO INFORMATION, PERSONAL OR OTHERWISE, IS SENT TO
CHEAT HAPPENS DURING THIS PROCESS. This check is only performed on trainers that have been
personalized for individual use, not our PROMO or FREE trainers. If you want/need to use the
trainer offline, please go to our trainer troubleshooting page for instructions on how to obtain
an offline key to avoid online checks.

If you want more trainers or mega trainer versions, when available, with more
options then visit us at WWW.CHEATHAPPENS.COM                                                                            